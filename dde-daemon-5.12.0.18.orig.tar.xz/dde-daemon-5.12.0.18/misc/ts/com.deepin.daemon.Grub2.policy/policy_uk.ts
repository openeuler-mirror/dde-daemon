<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.Grub2!message" line="0"/>
			<source>Authentication is required to change the grub2 configuration</source>
			<translation>Аутентифікація потрібна для зміни конфігурації grub2</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.Grub2!description" line="0"/>
			<source>Change the grub2 configuration</source>
			<translation>Змініть конфігурацію grub2</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!message" line="0"/>
			<source>Authentication is required to prepare grub2 display resolution detection</source>
			<translation>Потрібна аутентифікація для підготовки визначення роздільної здатності екрану grub2</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!description" line="0"/>
			<source>Prepare grub2 display resolution detection</source>
			<translation>Підготовка grub2 до визначення роздільної здатності екрану</translation>
		</message>
	</context>
</TS>