<?xml version="1.0" ?><!DOCTYPE TS><TS language="nl" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.Grub2!message" line="0"/>
			<source>Authentication is required to change the grub2 configuration</source>
			<translation>Authenticatie is vereist om de configuratie van grub2 te wijzigen</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.Grub2!description" line="0"/>
			<source>Change the grub2 configuration</source>
			<translation>Wijzig de grub2-configuratie</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!message" line="0"/>
			<source>Authentication is required to prepare grub2 display resolution detection</source>
			<translation>Authenticatie is vereist om de grub2 schermresolutie detectie voor te bereiden</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!description" line="0"/>
			<source>Prepare grub2 display resolution detection</source>
			<translation>Grub2 schermresolutie detectie voorbereiden</translation>
		</message>
	</context>
</TS>