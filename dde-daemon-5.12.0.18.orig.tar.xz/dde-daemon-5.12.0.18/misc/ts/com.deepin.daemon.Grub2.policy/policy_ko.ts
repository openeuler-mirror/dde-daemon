<?xml version="1.0" ?><!DOCTYPE TS><TS language="ko" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.Grub2!message" line="0"/>
			<source>Authentication is required to change the grub2 configuration</source>
			<translation>grub2 환경설정을 변경하려면 인증이 필요합니다</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.Grub2!description" line="0"/>
			<source>Change the grub2 configuration</source>
			<translation>grub2 환경설정 변경</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!message" line="0"/>
			<source>Authentication is required to prepare grub2 display resolution detection</source>
			<translation>grub2 디스플레이 해상도 감지를 준비하려면 인증이 필요합니다</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!description" line="0"/>
			<source>Prepare grub2 display resolution detection</source>
			<translation>grub2 디스플레이 해상도 감지 준비</translation>
		</message>
	</context>
</TS>