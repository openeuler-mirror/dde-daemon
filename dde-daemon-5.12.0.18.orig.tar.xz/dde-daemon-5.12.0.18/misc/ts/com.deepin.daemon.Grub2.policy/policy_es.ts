<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.1">
	<context>
		<name>policy</name>
		<message>
			<location filename="com.deepin.daemon.Grub2!message" line="0"/>
			<source>Authentication is required to change the grub2 configuration</source>
			<translation>Se requiere autenticación para modificar la configuración de grub2</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.Grub2!description" line="0"/>
			<source>Change the grub2 configuration</source>
			<translation>Cambiar la configuración de grub2</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!message" line="0"/>
			<source>Authentication is required to prepare grub2 display resolution detection</source>
			<translation>Se requiere autenticación para preparar la detección de resolución de pantalla en grub2</translation>
		</message>
		<message>
			<location filename="com.deepin.daemon.grub2.prepare-gfxmode-detect!description" line="0"/>
			<source>Prepare grub2 display resolution detection</source>
			<translation>Preparar la detección de resolución de pantalla en grub2</translation>
		</message>
	</context>
</TS>